
# LXON-7 — Clean Rebuild Plan

Faithful reproduction of the existing PDF design, rebranded from ITZSPACEAGE to **LXON-7 — AI Streaming Service**, using your uploaded logo, imagery, and background video. Marketing site only — all watch/subscribe CTAs point to `https://watch.lxon-7.com`.

## Assets

Upload via `lovable-assets` (kept off-repo, served from CDN):
- `WhatsApp_Image_2026-06-30_at_1.09.31_AM_1.png` → LXON-7 vertical logo (header + footer, used as-is, scaled up, background blends into surrounding dark section)
- `WhatsApp_Image_2026-06-30_at_1.09.31_AM.jpeg` → creator spotlight / secondary hero visual
- `WhatsApp_Image_2026-05-29_at_9.58.33_PM.png` → featured premiere still
- PDF-extracted stills (`img_p1_1`, `img_p2_1`, `img_p3_1`) → six trending cards (Neon Revenant, Void Whisper, Ocular Link, Canvas Zero, Crimson Orbit, Lumen City). Where a single still needs to cover multiple cards we'll tint/crop; if any card lacks a suitable source we'll generate a matching cosmic still in the same aesthetic.
- `Animate_image_looping_video_...mp4` → hero background video (autoplay, muted, loop, playsInline, `object-cover`, with a purple-black gradient scrim so it blends edge-to-edge)
- `other_video.mp4` → kept as fallback / optional secondary loop

## Route & structure

Single marketing page at `/` (TanStack route `src/routes/index.tsx`), shared `Header` + `Footer` components rendered from `__root.tsx`. `head()` set to real LXON-7 title/description/OG tags.

Sections in this exact order (matches PDF):
1. **Header** — LXON-7 logo (large, background blended, no visible box), nav: Home · Films · Series · Documentaries · AI Style · Submit, plus highlighted "Submit Your Film" CTA. Hamburger on mobile (Sheet).
2. **Hero** — full-bleed looping background video + cosmic gradient scrim. Kicker "● AI STREAMING PLATFORM", H1 "The Future of Entertainment, Streaming Now.", sub copy, CTAs "Watch Trailers" / "Explore the Catalog" → watch.lxon-7.com. "Come Join The Family" tagline chip.
3. **Featured Premiere** — kicker "NOW SHOWING", "AI FILM 2026 · 1H 48M · SCI-FI ODYSSEY", H2 "THE DAWN OF SYNTHETIC CINEMA", body copy (Directed by AXON-7 — exclusive premiere on LXON-7), "Watch Trailer" CTA. Featured still on the opposite side.
4. **Explore the Universe** — 4 category cards: AI Films, AI Mini Series, AI Documentaries, AI Style, each with "Browse Now →" → watch.lxon-7.com.
5. **Trending This Cycle** — "What The Galaxy Is Watching", 6-card grid (Neon Revenant / Void Whisper / Ocular Link / Canvas Zero / Crimson Orbit / Lumen City with their genre tags and creator credits), "View All Trailers →".
6. **Creator Spotlight — AXON-7** — portrait + bio, "View Filmography" / "Follow Creator".
7. **Come Join The Family / Submit** — "AI Creators, This Is Your Stage.", 3 bullets (Featured on LXON-7 AI Streaming Platform / Global Audience Reach / Partnerships & Collaborations), "Submit Now →" / "View Submission Guidelines".
8. **Tagline band** — "ONE PLATFORM. ENDLESS CREATORS. LIMITLESS POSSIBILITIES." Fluid type (`clamp`) so it never clips at any width.
9. **Footer** — LXON-7 logo (large, blended), brand line, three columns: **Browse** (AI Films, AI Mini Series, AI Documentaries, AI Style), **Studio** (Submit Your Film, Creator Guidelines, Partnerships, About, Contact), **Legal** (Privacy Policy, Terms of Use, Subscription & Payment Policy, Cancellation Policy, Refund Policy, Copyright Policy), prominent **Investor Relations** link. Bottom bar: "© 2026 LXON-7 — AI Streaming Services" left, "WATCH.LXON-7.COM →" right.

All Watch / Browse / Explore / Subscribe / Trailer / Start Watching links → `https://watch.lxon-7.com` (single constant, easy to swap).

## Design system (`src/styles.css`)

Dark cosmic tokens in `@theme` + `:root`:
- `--background` deep black `oklch(0.06 0.02 285)`, matched to the hero video's purple-black so the video blends with zero seam
- `--primary` electric purple, `--accent` cyan, plus `--neon-magenta`
- `--gradient-hero` (radial purple → black), `--gradient-heading` (white → purple, for the two-tone H1/H2 look), `--gradient-scrim` (transparent → black, for text-over-image legibility)
- `--shadow-glow` purple neon glow for hover lift on cards/posters
- Starfield: subtle CSS radial-gradient dots layer behind sections
- Fonts loaded via `<link>` in `__root.tsx` head: **Orbitron** (display, wide sci-fi headings + kickers with wide tracking) and **Inter** (body). Registered as `--font-display` / `--font-sans` in `@theme`.

Zero hardcoded color utilities in components — everything through semantic tokens so light/dark and future theming stay clean.

## Polish requirements (the point of the refresh)

- Fully responsive at 360 / 768 / 1024 / 1440. Header collapses to hamburger < `md`. Category + trending grids: 1 → 2 → 3 (or 2 → 3 for trending) columns.
- Every text-over-image block gets a bottom-anchored dark gradient scrim for readability.
- Consistent vertical rhythm: section padding `py-24 md:py-32`, container `max-w-7xl px-6 md:px-10`, card gap `gap-6 md:gap-8`.
- Tagline band uses `clamp()` so "ONE PLATFORM. ENDLESS CREATORS. LIMITLESS POSSIBILITIES." never clips.
- Use `min-w-0` + `truncate` / `shrink-0` per the responsive-layout pattern on header row and card headers.
- Motion (framer-motion): hero fades/slides in on load; sections + cards fade-slide up on scroll with stagger (`whileInView`, `viewport={{ once: true }}`); cards get hover lift + purple glow; buttons get smooth transitions. Motion is GPU-friendly (`transform`/`opacity` only). Respects `prefers-reduced-motion`.
- Hero video: `autoPlay muted loop playsInline preload="metadata"`, `object-cover`, absolute-positioned behind hero content, wrapped in a radial + linear scrim so edges blend into `--background`. Poster frame from the video's first frame as fallback.

## Technical notes

- Install `framer-motion` for animations.
- New files: `src/components/site/Header.tsx`, `Footer.tsx`, `HeroVideo.tsx`, `SectionKicker.tsx`, `PosterCard.tsx`, `CategoryCard.tsx`; `src/lib/links.ts` (WATCH_URL constant).
- Update `src/routes/__root.tsx`: real LXON-7 head metadata, Orbitron+Inter `<link>` preconnect + stylesheet, `<Header />` + `<main><Outlet /></main>` + `<Footer />`.
- Replace `src/routes/index.tsx` placeholder with the composed sections.
- No backend, no auth, no Supabase — pure marketing surface.

## Verification before finishing

- Build passes.
- Manual pass at 360 / 768 / 1440 via Playwright screenshots: no overflow, tagline intact, hamburger works, video autoplays, all text over images readable, logo blends with no visible box, footer columns aligned.
